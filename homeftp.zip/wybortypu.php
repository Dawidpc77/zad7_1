<?php
$dbhost="localhost"; $dbuser="25653832_zad6"; $dbpassword="Dawidnoski7@"; $dbname="25653832_zad6";
$polaczenie = mysqli_connect ($dbhost, $dbuser, $dbpassword);
mysqli_select_db ($polaczenie, $dbname);
$logowanie = mysqli_query ($polaczenie, "SELECT `pytania` FROM `z6zapytania`ORDER by `id`ASC ");
$index=0;
while ($wierszl = mysqli_fetch_array ($logowanie)){
  $pyt1[$index]=$wierszl[0];
$index++;
  }
  $loginn=$_COOKIE['login'];
////
print "<TABLE CELLPADDING=5 BORDER=1>";
print "<TR><TD>ip</TD><TD>data</TD></TR>\n";
  $odb3 = mysqli_query ($polaczenie, "SELECT `ip`,`data` FROM `z6klient`inner join `z6logklienta` using (`idk`) WHERE `login`='$loginn' GROUP BY `data` ORDER BY `data`  ");
  while ($wierszl = mysqli_fetch_array ($odb3)){
      $log1=$wierszl[0];
  $typ1=$wierszl[1];
   $odpo=$wierszl[2];
  $idp1=$wierszl[3];
   print"<TD>$log1</TD><TD>$typ1</TD>\n";
  print "<TR>";
  }
  echo 'OSTATNIE LOGOWANIA UŻYTKOWNIKA: '.$loginn;
  

echo '</table><br />';
/////
?>
WYBIERZ TYP ZGLOSZENIA ABY WYSWIETLIC HISTORIE
<form method="POST" action="historia.php" >
<br>
<select name="pytanie2">
    <option value="pyt1"><?php echo $pyt1[0]; ?></option>
    <option value="pyt2"><?php echo $pyt1[1]; ?></option>
    <option value="pyt3"><?php echo $pyt1[2]; ?></option>
     <option value="pyt4"><?php echo $pyt1[3]; ?></option>
     <br>
</select>
<input type="submit" value="wyslij"/>
</form>
<br><br>