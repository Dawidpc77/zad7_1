<?php
header( "refresh:3;url=klient.php" );
?>
Zgoszenie jest puste- prosimy o uzupelnienie informacji.