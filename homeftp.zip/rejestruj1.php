<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="utf-8"> 
      <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
  </head>
<body>


<div class="container">
    <form method="POST" action="typkonta.php">
    <br>
        <div class="form-group">
        <h1>Rejestracja</h1>
    
    </form>
    <form method="POST" action="zarejestruj.php">
    <br>
    
    <div class="form-group">
    
             <label for="login2">login</label>
             <input type="text" class="form-control" id="login2"  name="login1">
             <label for="haslo2">haslo</label>
            <input type="password" class="form-control" id="haslo2"  name="haslo1">
             <button type="submit" class="btn btn-primary">rejestruj</button>
        </div>

    </form>
      
</div>
</body>
</html>