<?php
header( "refresh:3;url=pracownik.php" );
?>
PODANO BŁĘDNY NUMER ZGŁOSZENIA
nie można odpowiedziec na dane zgloszenie- trwa przekierowanie