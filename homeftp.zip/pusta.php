<?php
header( "refresh:3;url=odpowiadanie.php" );
?>
Zgoszenie jest puste- prosimy o uzupelnienie informacji.