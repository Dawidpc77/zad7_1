<?php

if(isset($_COOKIE['login'])){
 header("Location: /z7/".$_COOKIE['login']."/index.php");}
  //header("Refresh: 1; URL=http://serwer1769034.home.pl/z7/$idz/index.php");}
  //$idz=$_COOKIE['login'];
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8"> 
      <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
  <title>Witaj</title>
  </head>
<body>


<div class="container">
<main>
        <form method="POST" action="przenies.php">
        <br>
            <div class="form-group">
            <h1>Dawid's Cloud</h1>
        
                 <label for="login1">login</label>
                 <input type="text" class="form-control" id="login1"  name="login" value="66">
                 <label for="haslo1">haslo</label>
                <input type="password" class="form-control" id="haslo1"  name="haslo" value="123">
                 <button type="submit" class="btn btn-primary">zaloguj</button>
                 <a href='http://serwer1769034.home.pl/z7/rejestruj1.php'> Nie posiadasz konta? Zarejestruj sie !</a>
            </div>
        </form>
      
        
        <form action="http://serwer1769034.home.pl/z7/usuncookie.php">
            <input type="submit" value="usun zapisane haslo" />
    </form>
</main>
</div>
   <footer>
      <p>Copyright (c) 2017</p>
   </footer>
</body>
</html>