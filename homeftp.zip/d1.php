<?php
// You need to create the files/ directory inside your document root to put your files.
if (substr($_SERVER['REQUEST_URI'], 0, 4) !== '/z7/') {
    echo $_SERVER['REQUEST_URI'];
    die('not allowed');
}
$absolutePath = $_SERVER['DOCUMENT_ROOT'] . $_SERVER['REQUEST_URI'];
$pathParts = pathinfo($absolutePath);
$fileName = $pathParts['basename'];
$fileInfo = finfo_open(FILEINFO_MIME_TYPE);
$fileType = finfo_file($fileInfo, $absolutePath);
finfo_close($fileInfo);
$fileSize = filesize($absolutePath);
//echo 'sciezka: '.$fileName;

//header('Content-Length: ' . $fileSize);
//header('Content-Type: ' . $fileType);
header('Content-Disposition: attachment; filename=' . $fileName);
//ob_clean();
flush();
//readfile($absolutePath);
exit;
?>