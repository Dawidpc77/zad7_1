<?php
header( "refresh:3;url=rejestruj.php" );

$dbhost="localhost"; $dbuser="25653832_zad7"; $dbpassword="Dawidnoski7@"; $dbname="25653832_zad7";
$polaczenie = mysqli_connect ($dbhost, $dbuser, $dbpassword);
mysqli_select_db ($polaczenie, $dbname);
$login1 = $_POST['login1'];
$haslo1 = $_POST['haslo1'];
if($login1==''||$haslo1==''){
    echo 'Prosze podac poprawne dane';
     header("refresh:3;url=rejestruj.php");}else{
$rejestr = mysqli_query ($polaczenie," INSERT INTO `users`(`login`,`haslo`) VALUES ('$login1','$haslo1')");

$biezkat1= getcwd();
if($login1!=''){
$katalog='cos2';//nazwa jaka przyjmie katalog
if (!file_exists("$biezkat1/$login1")) {
mkdir("$biezkat1/$login1");}
$zmienna="$biezkat1/$login1";
echo $zmienna;
echo $login;
echo $sciezka;
//echo "<META  http-equiv='refresh' content='0'; URL=''>";
}else{
    echo 'juz istnieje';
}

/*
$file = 'http://serwer1769034.home.pl/z7/kopie/index.php';
$newfile = "$biezkat1/$login/index.php";

if (!copy($file, $newfile)) {
    echo "failed to copy $file...\n";
}
*/
$file1 = '/z7/temp/index.php';
$newfile1 = "$biezkat1/$login1/index.php";

if (!copy($file1, $newfile1)) {
    echo "failed to copy $file1...\n";
}
$file12 = '/z7/temp/odbierz1.php';
$newfile12 = "$biezkat1/$login1/odbierz1.php";

if (!copy($file12, $newfile12)) {
    echo "failed to copy $file1...\n";
}


}



?>
