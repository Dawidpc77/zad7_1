<?php
header( "refresh:3;url=usuncookie.php" );
?>
Dziekujemy twoje zgloszenie zostalo wyslane