<?php 
$dbhost="localhost"; $dbuser="25653832_zad7"; $dbpassword="Dawidnoski7@"; $dbname="25653832_zad7";
$polaczenie = mysqli_connect ($dbhost, $dbuser, $dbpassword);
mysqli_select_db ($polaczenie, $dbname);
$login = $_POST['login'];
$haslo = $_POST['haslo'];

if(!isset($_COOKIE['login'])){
setcookie('login', $login, time()+360000);
setcookie('haslo', $haslo, time()+360000);
}else{
    $login=$_COOKIE['login'];
    $haslo=$_COOKIE['haslo'];
}
$dane=0;
$logowanie = mysqli_query ($polaczenie, "SELECT `id`,`login`,`haslo` FROM `users` ORDER BY `id` ASC");
while ($wierszl = mysqli_fetch_array ($logowanie)){
  $logg1=$wierszl[0];
  $logg=$wierszl[1];
  $pass=$wierszl[2];
if($logg==$login&&$pass==$haslo){
    header("Location: /z7/".$login."/index.php");
$dane++;
}
}
if($dane==0){
header("Location: usuncookie.php");}



?>