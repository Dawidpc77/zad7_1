<?php
$katalog='cos2';//nazwa jaka przyjmie katalog
if (!file_exists("../z7/$katalog")) {
mkdir("../z7/$katalog");

}else{
    echo 'juz istnieje';
}


$file = 'http://serwer1769034.home.pl//z7/kopie/index.php';
$newfile = $katalog.'/index.php';

if (!copy($file, $newfile)) {
    echo "failed to copy $file...\n";
}



//if(is_dir("../z7/$katalog")){
//$zawartosc_katalogu = readdir("../z7/$katalog");
//}else{
//echo('podany plik nie jest katalogiem');

?>