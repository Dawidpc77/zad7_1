<?php

$dbhost="localhost"; $dbuser="25653832_zad7"; $dbpassword="Dawidnoski7@"; $dbname="25653832_zad7";
$polaczenie = mysqli_connect ($dbhost, $dbuser, $dbpassword);
mysqli_select_db ($polaczenie, $dbname);
$login = $_POST['login'];
$haslo = $_POST['haslo'];

if(!isset($_COOKIE['login'])){
setcookie('login', $login, time()+360000);
setcookie('haslo', $haslo, time()+360000);
}else{
    $login=$_COOKIE['login'];
    $haslo=$_COOKIE['haslo'];
}
$dane=0;
$logowanie = mysqli_query ($polaczenie, "SELECT `id`,`login`,`haslo` FROM `users` ORDER BY `id` ASC");
while ($wierszl = mysqli_fetch_array ($logowanie)){
  $logg1=$wierszl[0];
  $logg=$wierszl[1];
  $pass=$wierszl[2];
if($logg==$login&&$pass==$haslo){
$dane++;
}
}
if($dane==0){
header("Location: usuncookie.php");}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="utf-8"> 
      <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>

  </head>
<body>



<div class="container">
  <h2>Otwórz katalog lub pobierz plik</h2>



<div class="row">
<?php
$biezkat1= getcwd();
$katalog    = $biezkat1;

$pliki = scandir($katalog);
echo "<div class=".'"container"'.">";
echo "<div class=".'"row">';
$liczile=0;
$ilekolumn=0;
$ilewkolumnie=0;
$dirs = array_filter(glob('*'), 'is_dir');
echo $dirs[5];
foreach($pliki as $plik1){
    $ilewkolumnie++;}
foreach($pliki as $plik)  {

    if($plik!='.'&&$plik!='..'&&$plik!='index.php') {
        
        
        if(is_dir("$biezkat1/$plik")){
        
        if($liczile==0){
  
    echo '<div class="col" style="background-color:lavender;">'."<p><a href='http://serwer1769034.home.pl/$biezkat1/$plik' class='text-warning'> $plik</a><br></p>";
    $liczile++;}else {
        echo "<p><a href='http://serwer1769034.home.pl/$biezkat1/$plik' class='text-warning'> $plik</a><br></p>";
        $liczile++;
          if($liczile==round($ilewkolumnie/5)){
                 echo "</div>";
                 $liczile=0;
           
                 
               //  echo "</div>";
          }}
    }else{
    if($liczile==0){
  
    echo '<div class="col" style="background-color:lavender;">'."<p><a href='http://serwer1769034.home.pl/$biezkat1/$plik' class='text-success'  download> $plik</a><br></p>";
    $liczile++;}else {
        echo "<p><a href='http://serwer1769034.home.pl/$biezkat1/$plik' class='text-success' download> $plik</a><br></p>";
        $liczile++;
          if($liczile==round($ilewkolumnie/5)){
                 echo "</div>";
                 $liczile=0;
           
                 
                 
               //  echo "</div>";
          }}
    }
    }}
  //  for($a=0;$a<$ilekolumn2;$a++){
      //  echo "</div>";
    //}
    
     echo "</div>";
 echo "</div>";

?>


<?php
$biezkat1= getcwd();
$login = $_COOKIE['login'];
/*$login = $_COOKIE['login'];
$sciezka = $_POST['sciezka'];
$login1 = $_POST['login1'];
$biezkat1= getcwd();
if($login1!=''){
$katalog='cos2';//nazwa jaka przyjmie katalog
if (!file_exists("$biezkat1/$sciezka")) {
mkdir("$biezkat1/$sciezka");
$zmienna="$biezkat1/$sciezka";


/*
$file = 'http://serwer1769034.home.pl/z7/kopie/index.php';
$newfile = "$biezkat1/$login/index.php";

if (!copy($file, $newfile)) {
    echo "failed to copy $file...\n";
}

$file1 = '/z7/temp/index.php';
$newfile1 = "$biezkat1/$login1/index.php";

if (!copy($file1, $newfile1)) {
    echo "failed to copy $file1...\n";
}
$file12 = '/z7/temp/odbierz1.php';
$newfile12 = "$biezkat1/$login1/odbierz1.php";

if (!copy($file12, $newfile12)) {
    echo "failed to copy $file1...\n";
}

//echo "<META  http-equiv='refresh' content='0'; URL=''>";
else{
    echo 'juz istnieje';
}
}*/

//header("Location: $login1/index.php");
echo "<META  http-equiv='refresh' content='1'; URL='http://serwer1769034.home.pl$biezkat1/$login/'>";
echo "'http://serwer1769034.home.pl$biezkat1/$login/'";
?>


<div class="container">
 
  <form action="odbierz1.php" method="POST" ENCTYPE="multipart/form-data">
    <div class="form-group">
      <label for="email">Wybierz plik do wyslania</label>
      <input type="file" class="form-control" id="email"  name="plik">
    </div>
    <button type="submit" class="btn btn-primary">Wyslij</button>
  </form>
  
     <form method="POST" action="">
    <br>
        <div class="form-group">
    
             <label for="sciez">Podaj nazwe nowego katalogu</label>
             <input type="text" class="form-control" id="sciez"  name="sciezka">
             <button type="submit" class="btn btn-primary">Utwórz</button>
          
        </div>
    </form>
  
</div>



</body>
</html>