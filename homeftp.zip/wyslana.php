<?php
header( "refresh:3;url=usuncookie.php" );
?>
Udzielono odpowiedzi na zgloszenie- nastepuje wylogowanie