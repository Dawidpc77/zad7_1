<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="utf-8"> 
      <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
  </head>
<body>



<div class="container">
  <h2>Wybierz plik do pobrania</h2>

</div>

<div class="row">


<?php
$katalog    = './';
$pliki = scandir($katalog);
echo "<div class=".'"container"'.">";
echo "<div class=".'"row">';
$liczile=0;
$ilekolumn=0;
$ilewkolumnie=0;
$dirs = array_filter(glob('*'), 'is_dir');
echo $dirs[5];
foreach($pliki as $plik){
    $ilewkolumnie++;}
foreach($pliki as $plik)  {

    if($plik!='.'&&$plik!='..') {
        
        //
        if(!is_dir($plik)){
        //
        if($liczile==0){
  
    echo '<div class="col" style="background-color:lavender;">'."<p><a href='http://serwer1769034.home.pl/z7/$plik'> $plik</a><br></p>";
    $liczile++;}
    else {
        echo "<p><a href='http://serwer1769034.home.pl/z7/$plik'> $plik</a><br></p>";
        $liczile++;
          if($liczile==round($ilewkolumnie/5)){
                 echo "</div>";
                 $liczile=0;
           
                 
               //  echo "</div>";
          }}
    }}}
  //  for($a=0;$a<$ilekolumn2;$a++){
      //  echo "</div>";
    //}
    
     echo "</div>";
 echo "</div>";
 echo $ilewkolumnie;
 echo round($ilewkolumnie/5)
?>

</body>
</html>