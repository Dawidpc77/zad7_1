<?php
$biezkat1= getcwd();
$login = $_COOKIE['login'];
if($login!=''){
$katalog='cos2';//nazwa jaka przyjmie katalog
if (!file_exists("$biezkat1/$login")) {
mkdir("$biezkat1/$login");}
$zmienna="$biezkat1/$login";
echo $zmienna;
echo $login;
echo $sciezka;
echo "<META  http-equiv='refresh' content='0'; URL=''>";
}else{
    echo 'juz istnieje';
}

/*
$file = 'http://serwer1769034.home.pl/z7/kopie/index.php';
$newfile = "$biezkat1/$login/index.php";

if (!copy($file, $newfile)) {
    echo "failed to copy $file...\n";
}
*/
$file1 = 'http://serwer1769034.home.pl/z7/typkonta.php';
$newfile1 = "$biezkat1/$login/index.php";

if (!copy($file1, $newfile1)) {
    echo "failed to copy $file...\n";
}


?>