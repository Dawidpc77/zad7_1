-- phpMyAdmin SQL Dump
-- version home.pl
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Czas wygenerowania: 13 Gru 2017, 01:10
-- Wersja serwera: 5.7.19-17-log
-- Wersja PHP: 7.1.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Baza danych: `25653832_zad6`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `z6dialog`
--

CREATE TABLE IF NOT EXISTS `z6dialog` (
  `loginpracownika` text NOT NULL,
  `loginklienta` text NOT NULL,
  `pyt1` text NOT NULL,
  `pyt2` text NOT NULL,
  `pyt3` text NOT NULL,
  `pyt4` text NOT NULL,
  `odpowiedz` text NOT NULL,
  `idp` int(11) NOT NULL AUTO_INCREMENT,
  `idk` int(11) NOT NULL,
  UNIQUE KEY `idp` (`idp`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin2 AUTO_INCREMENT=13 ;

--
-- Zrzut danych tabeli `z6dialog`
--

INSERT INTO `z6dialog` (`loginpracownika`, `loginklienta`, `pyt1`, `pyt2`, `pyt3`, `pyt4`, `odpowiedz`, `idp`, `idk`) VALUES
('login11', 'login', '', 'czy to juz koniec?', '', '', 'tak', 1, 1),
('login11', 'login', '', 'czy aby na pewno?', '', '', 'odp', 2, 1),
('', 'login', '', '', '', '', '', 3, 1),
('', 'login', '', '', '', '', '', 4, 1),
('', 'login', '', '', 'zgloszenie', '', '', 5, 1),
('', 'login2', 'wysylam', '', '', '', '', 10, 2),
('', 'login', '', '', '', 'zgloszenie1', '', 11, 1),
('', 'login', '', '', '', 'zgloszenie2', '', 12, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `z6klient`
--

CREATE TABLE IF NOT EXISTS `z6klient` (
  `idk` int(11) NOT NULL AUTO_INCREMENT,
  `login` text NOT NULL,
  `haslo` text NOT NULL,
  PRIMARY KEY (`idk`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin2 AUTO_INCREMENT=5 ;

--
-- Zrzut danych tabeli `z6klient`
--

INSERT INTO `z6klient` (`idk`, `login`, `haslo`) VALUES
(1, 'login', 'haslo3'),
(2, 'login2', 'haslo2');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `z6logklienta`
--

CREATE TABLE IF NOT EXISTS `z6logklienta` (
  `idk` int(11) NOT NULL,
  `ip` text NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nrsesji` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`nrsesji`),
  UNIQUE KEY `unique_index` (`nrsesji`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin2 AUTO_INCREMENT=16 ;

--
-- Zrzut danych tabeli `z6logklienta`
--

INSERT INTO `z6logklienta` (`idk`, `ip`, `data`, `nrsesji`) VALUES
(1, '77.113.84.189', '2017-12-12 22:32:53', 1),
(1, '77.113.84.189', '2017-12-12 22:53:49', 2),
(1, '77.113.84.189', '2017-12-12 22:54:22', 3),
(1, '89.64.23.51', '2017-12-12 22:56:28', 4),
(1, '89.64.23.51', '2017-12-12 22:56:41', 5),
(1, '77.113.84.189', '2017-12-12 23:05:06', 6),
(1, '89.64.23.90', '2017-12-12 23:06:53', 7),
(1, '89.64.23.90', '2017-12-12 23:07:45', 8),
(2, '77.113.84.189', '2017-12-12 23:24:33', 9),
(2, '77.113.84.189', '2017-12-12 23:24:50', 10),
(2, '77.113.84.189', '2017-12-12 23:47:06', 11),
(2, '77.113.84.189', '2017-12-12 23:47:44', 12),
(1, '77.113.84.189', '2017-12-12 23:52:28', 13),
(1, '77.113.84.189', '2017-12-12 23:53:51', 14),
(1, '77.113.84.189', '2017-12-12 23:54:53', 15);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `z6logpracownika`
--

CREATE TABLE IF NOT EXISTS `z6logpracownika` (
  `idp` int(11) NOT NULL,
  `ip` text NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nrsesji` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`nrsesji`),
  UNIQUE KEY `unique_index` (`nrsesji`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin2 AUTO_INCREMENT=51 ;

--
-- Zrzut danych tabeli `z6logpracownika`
--

INSERT INTO `z6logpracownika` (`idp`, `ip`, `data`, `nrsesji`) VALUES
(1, '77.113.84.189', '2017-12-12 21:34:47', 1),
(1, '77.113.84.189', '2017-12-12 21:43:19', 2),
(1, '77.113.84.189', '2017-12-12 21:49:40', 3),
(1, '77.113.84.189', '2017-12-12 21:57:54', 4),
(1, '77.113.84.189', '2017-12-12 21:57:54', 5),
(1, '77.113.84.189', '2017-12-12 22:07:49', 6),
(1, '77.113.84.189', '2017-12-12 22:09:58', 7),
(1, '77.113.84.189', '2017-12-12 22:10:02', 8),
(1, '77.113.84.189', '2017-12-12 22:11:08', 9),
(1, '77.113.84.189', '2017-12-12 22:11:39', 10),
(1, '77.113.84.189', '2017-12-12 22:11:40', 11),
(1, '77.113.84.189', '2017-12-12 22:12:20', 12),
(1, '77.113.84.189', '2017-12-12 22:12:20', 13),
(1, '77.113.84.189', '2017-12-12 22:14:07', 14),
(1, '77.113.84.189', '2017-12-12 22:14:08', 15),
(1, '77.113.84.189', '2017-12-12 22:14:09', 16),
(1, '77.113.84.189', '2017-12-12 22:15:24', 17),
(1, '77.113.84.189', '2017-12-12 22:15:49', 18),
(1, '77.113.84.189', '2017-12-12 22:16:45', 19),
(1, '77.113.84.189', '2017-12-12 22:16:53', 20),
(1, '77.113.84.189', '2017-12-12 22:16:54', 21),
(1, '77.113.84.189', '2017-12-12 22:16:54', 22),
(1, '77.113.84.189', '2017-12-12 22:16:54', 23),
(1, '77.113.84.189', '2017-12-12 22:17:04', 24),
(1, '77.113.84.189', '2017-12-12 22:17:05', 25),
(1, '77.113.84.189', '2017-12-12 22:17:05', 26),
(1, '77.113.84.189', '2017-12-12 22:17:05', 27),
(1, '77.113.84.189', '2017-12-12 22:17:06', 28),
(1, '77.113.84.189', '2017-12-12 22:17:09', 29),
(1, '77.113.84.189', '2017-12-12 22:17:19', 30),
(1, '77.113.84.189', '2017-12-12 22:19:26', 31),
(1, '77.113.84.189', '2017-12-12 22:20:20', 32),
(1, '77.113.84.189', '2017-12-12 22:20:31', 33),
(1, '77.113.84.189', '2017-12-12 22:31:10', 34),
(1, '77.113.84.189', '2017-12-12 22:32:39', 35),
(1, '77.113.84.189', '2017-12-12 22:33:16', 36),
(1, '77.113.84.189', '2017-12-12 22:33:18', 37),
(1, '77.113.84.189', '2017-12-12 22:33:19', 38),
(1, '77.113.84.189', '2017-12-12 22:37:42', 39),
(1, '77.113.84.189', '2017-12-12 22:37:43', 40),
(1, '77.113.84.189', '2017-12-12 22:41:13', 41),
(1, '77.113.84.189', '2017-12-12 22:42:11', 42),
(1, '77.113.84.189', '2017-12-12 22:48:04', 43),
(1, '77.113.84.189', '2017-12-12 22:48:30', 44),
(1, '77.113.84.189', '2017-12-12 22:49:25', 45),
(1, '77.113.84.189', '2017-12-12 22:52:15', 46),
(1, '89.64.23.51', '2017-12-12 22:55:21', 47),
(1, '89.64.23.51', '2017-12-12 22:55:56', 48),
(1, '77.113.84.189', '2017-12-12 23:41:18', 49),
(1, '77.113.84.189', '2017-12-12 23:42:08', 50);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `z6pracownik`
--

CREATE TABLE IF NOT EXISTS `z6pracownik` (
  `idp` int(11) NOT NULL AUTO_INCREMENT,
  `login` text NOT NULL,
  `haslo` text NOT NULL,
  PRIMARY KEY (`idp`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin2 AUTO_INCREMENT=2 ;

--
-- Zrzut danych tabeli `z6pracownik`
--

INSERT INTO `z6pracownik` (`idp`, `login`, `haslo`) VALUES
(1, 'login11', 'haslo11');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `z6zapytania`
--

CREATE TABLE IF NOT EXISTS `z6zapytania` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pytania` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin2 AUTO_INCREMENT=5 ;

--
-- Zrzut danych tabeli `z6zapytania`
--

INSERT INTO `z6zapytania` (`id`, `pytania`) VALUES
(1, 'Problemy techniczne'),
(2, 'Platnosci'),
(3, 'Uslugi'),
(4, 'Inne');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
